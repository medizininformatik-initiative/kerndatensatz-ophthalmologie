# Profiles - MII Implementation Guide Ophthalmologie v2028.0.0-alpha.1

* [**Table of Contents**](toc.md)
* **Profiles**

## Profiles

This page lists the FHIR profiles of the **Ophthalmologie** module. As a starting point the template ships one minimal example profile, [Example Patient](StructureDefinition-example-patient.md) — replace it with your module's profiles (naming convention `MII_PR_<Module>_<Name>`, see the [`docs/recipes/add-a-profile.md`](https://github.com/medizininformatik-initiative/kerndatensatz-ophthalmologie/blob/main/docs/recipes/add-a-profile.md) in this repository, and the MII naming conventions). The module's extensions are listed on the [Extensions](extensions.md) page.

> [TODO: Describe your module's profiles and how they relate to each other. The IG Publisher generates the technical detail pages automatically.]

