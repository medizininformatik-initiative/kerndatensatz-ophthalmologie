# Anleitung für Implementierende - MII Implementation Guide Ophthalmologie v2028.0.0-alpha.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Anleitung**](guidance.md)
* **Anleitung für Implementierende**

## Anleitung für Implementierende

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Technische Hinweise für DIZ-Implementierende zur Umsetzung der Profile des Moduls **Ophthalmologie** (ETL aus Primärsystemen, FHIR-API, Validierung).

> [TODO: Beschreiben Sie die technischen Umsetzungsschritte für Ihr Modul.]

